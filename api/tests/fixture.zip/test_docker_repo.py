from pathlib import Path

import pytest

from src.repos.archive_repo import ArchiveRepo
from src.repos.docker_repo import docker_repo


@pytest.fixture(scope='session')
async def init():
    await docker_repo.init()


async def test_repo():
    path = Path(__file__).parent / 'fixture.tar.gz'
    with open(path, 'rb') as file:
        async for value in docker_repo._docker_client.images.build(fileobj=file, tag='test:v1', stream=True, encoding='gzip'):
            print(value)

    await docker_repo._docker_client.containers.run(
        {
            "Image": "test:v1"
        }
    )


async def test_uploadfile():
    repo = ArchiveRepo()
    path = Path(__file__).parent / 'tests' / 'hello.zip'
    with open(Path(__file__).parent / 'fixture.zip', 'rb') as buffer:
        await repo.create_tar(path, buffer, 'dima4', 'dima4')
